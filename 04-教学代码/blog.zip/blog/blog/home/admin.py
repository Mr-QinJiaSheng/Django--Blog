from django.contrib import admin
from home.models import ArticleCategory
# Register your models here.
#注册模型
admin.site.register(ArticleCategory)